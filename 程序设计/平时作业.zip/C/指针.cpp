#include<stdio.h>
int main()
{
	long int i;
	i=5;
	long int *p;
	p=&i;
	printf("p+1=%p",p+1);
	return 0;
 } 
