#include <stdio.h>

#define MAX_STUDENTS 10
#define NUM_SUBJECTS 3

int main() {
    char names[MAX_STUDENTS][50];
    float scores[MAX_STUDENTS][NUM_SUBJECTS];

    // 输入姓名和成绩
    for (int i = 0; i < MAX_STUDENTS; i++) {
        printf("请输入第%d个学生的姓名：", i + 1);
        scanf("%s", names[i]);
        for (int j = 0; j < NUM_SUBJECTS; j++) {
            printf("请输入%s的第%d门课成绩：", names[i], j + 1);
            scanf("%f", &scores[i][j]);
        }
    }

    // 找出每门课的最高分者
    for (int j = 0; j < NUM_SUBJECTS; j++) {
        float max_score = scores[0][j];
        char max_name[50];
        for (int k = 0; k < 50; k++) {
            max_name[k] = names[0][k];
            if (names[0][k] == '\0') {
                break;
            }
        }
        for (int i = 1; i < MAX_STUDENTS; i++) {
            if (scores[i][j] > max_score) {
                max_score = scores[i][j];
                for (int k = 0; k < 50; k++) {
                    max_name[k] = names[i][k];
                    if (names[i][k] == '\0') {
                        break;
                    }
                }
            }
        }
        printf("第%d门课最高分者姓名：%s\n", j + 1, max_name);
    }

    return 0;
}