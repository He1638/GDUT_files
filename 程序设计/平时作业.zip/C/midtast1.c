#include<stdio.h>
int main()
{
    int N;
    do{
        printf("请输入一个10到18的数:");
        scanf("%d",&N);
    }while(N>18||N<10);

    int i,j;
    int num[18][18];
    for(i=0;i<18;i++){
        for(j=0;j<=i;j++){
            num[i][j]=1;
        }
    }

    for(i=2;i<N;i++){
            for(j=1;j<i;j++){
                num[i][j]=num[i-1][j-1]+num[i-1][j];
            }
        }

     for(i=0;i<N;i++){
        for(j=0;j<i+1;j++){
            printf("%d\t",num[i][j]);
        }
        printf("\n");
    }
    return 0;        
}