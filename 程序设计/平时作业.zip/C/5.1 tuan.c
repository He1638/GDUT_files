#include<stdio.h>

int main()
{
//		判断是否奇数 
	int a=0;
	printf("请输入行数：");
	scanf("%d",&a);
	while(1){
		if(a%2==0){
			printf("请输入一个奇数:");
			scanf("%d",&a);
		}
		else{break;}	
    }	
//		上半部分
	int i,j,k;
		for(k=0;k<((a+1)/2);k++){
			for(i=0;i<((a+1)/2-k-1);i++){
				printf(" ");
			}
            printf("*");
			for(j=0;j<k;j++){
				printf(" *");
			}
		    printf("\n");
		}
//	    下半部分 
	int o,p,q;
		for(o=0;o<(a-k);o++){
			for(p=0;p<o+1;p++){
				printf(" ");
			}
            printf("*");
			for(q=0;q<(a-k-o-1);q++){
				printf(" *");
			}
			if(o+k+1!=a) {
                printf("\n");
            }
	    }

		return 0;
}