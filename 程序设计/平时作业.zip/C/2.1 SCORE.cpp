#include<stdio.h>
int main()
{
	float score;
	printf("请输入成绩：");
	scanf("%f",&score);
	if(score<0)
		{
		printf("输入的成绩为负数。");
		}
	if(score>=0 && score<60)
		{
		printf("成绩等级为D:60分以下") ;
		}
	if(score>=60 && score<70)
		{
		printf("成绩等级为C:60分及以上") ;
		}
	if(score>=70 && score<90)
		{
		printf("成绩等级为B:70分及以上") ;
		}
	if(score>=90 && score<=100)
		{
		printf("成绩等级为A:90分及以上") ;
		}
	if(score>100)
		{
		printf("输入的成绩超过100。");
		}
	return 0;
} 