#include <stdio.h>  
  
int main() {  
    double fahrenheit, celsius;  
  
    printf("请输入华氏度: ");  
    scanf("%lf", &fahrenheit);  
  
    // 直接在main函数中进行转换  
    celsius = (fahrenheit - 32) * 5.0 / 9.0;  
  
    printf("%.2lf 华氏度 = %.2lf 摄氏度\n", fahrenheit, celsius);  
  
    return 1;  
}