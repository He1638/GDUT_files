#include<stdio.h>
int main()
{
    int i=2;
    int x=2;
    int sum=0;
    for(i=2;i<100;i++){
        int isPrime=1;
        for(x=2;x<i;x++){
            if(i%x==0){
                isPrime=0;
                break;
            }
        }
        if(isPrime){
            sum+=i;
        }
    }
    printf("1到100之间所有质数的和为%d",sum);
    return 0;
}