#include<stdio.h>
int main()
{
    int i,j,temp;
    float num[5];
    float sum=0,ave;

    printf("请输入5个数:\n");    // 数组赋值
    for(i=0;i<5;i++){
        scanf("%f",&num[i]);
    }

    for(i=0;i<4;i++){            // 从小到大排序输出
        for(j=i+1;j<5;j++){
             if(num[i]>num[j]){
                temp=num[i];
                num[i]=num[j];
                num[j]=temp;
             }
        }
    }  
    printf("从小到大排序：\n");
    for(i=0;i<5;i++){
        printf("%f ",num[i]);
    }
    printf("\n");
    
    for(i=0;i<5;i++){           // 输出平均值
        sum+=num[i];
    }
    ave=sum/5;
    printf("平均值为：%f\n",ave);

    printf("最大值为：%f\n",num[4]);        //输出最大值
    
    return 0;
}