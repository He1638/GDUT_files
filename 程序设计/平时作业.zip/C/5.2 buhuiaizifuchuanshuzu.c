#include <stdio.h> 
#include <string.h>

int main() 
{ 
    char str[100]; 
    printf("请输入一个字符串："); 
    scanf("%s",str);

// 将小写字母转换为大写字母
    for(int i=0; str[i]!='\0';i++){
        if(str[i]>='a'&&str[i]<='z'){
            str[i]=str[i]-'a'+'A';
        }
    }

// 逆序输出字符串
    printf("转换后的字符串为：");
    for(int i=strlen(str)-1;i>=0;i--){
        printf("%c",str[i]);
    }
    printf("\n");

// 计算最大ASCII码距离
    int min_ascii=str[0];
    int max_ascii=str[0];
    for(int i=0; i<strlen(str);i++){
        if(str[i]<min_ascii){
            min_ascii=str[i];
        }
        if(str[i]>max_ascii){
            max_ascii=str[i];
        }
    }
    int max_distance=max_ascii-min_ascii;
    printf("字符串中字符的最大ASCII码距离为：%d\n",max_distance);
    return 0;
}