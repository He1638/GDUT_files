#include<stdio.h>
int main()
{
    printf("hello ");    
    
    printf("hello");
    return 0;
}