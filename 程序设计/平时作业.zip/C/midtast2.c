#include<stdio.h>
int main()
{
    // int num[]={100,101,102,103,104,105,106,107,108,109};
    char number[10][50]={100,101,102,103,104,105,106,107,108,109};
    int i,j;
    int a1=0,b2=0,c3=0,d4=0,e5=0,f6=0,g7=0,h8=0,i9=0,j0=0;
    // for(i=0;i<10;i++){
    //     number[i][50]=num[i];
    // }
    for(i=0;i<10;i++){
        for(j=0;number[i][j]!='\0';j++){
            switch(number[i][j]){
            case '1':a1++;break;
            case '2':b2++;break;
            case '3':c3++;break;
            case '4':d4++;break;
            case '5':e5++;break;
            case '6':f6++;break;
            case '7':g7++;break;
            case '8':h8++;break;
            case '9':i9++;break;
            case '0':j0++;break;
            }
        }
    }
    return 0;
}