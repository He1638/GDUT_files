#include<stdio.h>
int main()
{
    int i,x,y;
    printf("请输入横坐标与纵坐标：");
    scanf("%d%d",&x,&y);
    if(((x-2)*(x-2)+(y-2)*(y-2)<=1) || ((x+2)*(x+2)+(y-2)*(y-2)<=1) || ((x-2)*(x-2)+(y+2)*(y+2)<=1) || ((x+2)*(x+2)+(y+2)*(y+2)<=1))
        {
            i=1;
        }
    else
        {
            i=0;
        }
    switch(i)
    {
        case 1 :printf("高度为10");break;
        case 0 :printf("高度为0");break;
    }
return 0;
}