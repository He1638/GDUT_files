#include<stdio.h>
int main()
{
    int i,n,j;
    float sum2=0;
    for(n=1;n<=10;n++){
        float jiecheng=1;
        float dou,sum1=0,an;
        for(i=1;i<=n;i++){
            dou=i*i;
            sum1+=dou;
        }
        for(j=n;j>0;j--){
            jiecheng*=j;
        }
        an=sum1/jiecheng;
        sum2+=an;
    }
    printf("%f",sum2);
    return 0;
}