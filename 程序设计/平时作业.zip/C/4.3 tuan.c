#include<stdio.h>
int main()
{
	int n=0;
	printf("请输入一个偶数：");
	scanf("%d",&n);
	while(1){
        if(n%2!=0){
			printf("请输入一个偶数:");
			scanf("%d",&n);
		}
		else{break;}	
    }

    //上半个图案
	int i,j,k;
	for(k=0;k<n/2;k++){                //行数
		for(i=0;i<(n/2-k-1);i++){      //空格数
			printf(" ");
		}
        printf("+");
		for(j=0;j<k;j++){              //*+数
			printf("*+");
		}
		printf("\n");
	}

    //下半个图案
    int o,p,q;
	for(o=0;o<n-k;o++){               //行数
		for(p=0;p<o;p++){             //空格数
			printf(" ");
		}
        printf("+");
		for(q=0;q<n/2-o-1;q++){       //*+数
			printf("*+");
        }
		if(k+o+2<=n) 
		  {printf("\n");}
	}
	return 0;
}
