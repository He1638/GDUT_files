#include<stdio.h>
int main()
{
    int i,j;
    int cnt,start,stop;
    printf("请输入起点和终点：");
    scanf("%d %d",&start,&stop);
    for(cnt=start;cnt<=stop;cnt++){
        for(i=1;i<=cnt;i++){
            for(j=1;j<=cnt;j++){
                printf("%d×%d=%d\t",i,j,i*j); 
            }
            printf("\n");
        }
        printf("\n");
    }
    return 0;
}