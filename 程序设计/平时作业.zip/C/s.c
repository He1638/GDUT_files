#include<stdio.h>

int main()
{
	int a[];
	for(i=0;i<strlen(a);i++)
	a[i]=0;
 } 
