#include<stdio.h>
int main()
{
    float c,f;
    float start,stop,step;
    int i=0;
    printf("请输入起点、终点和步长：");
    scanf("%f%f%f",&start,&stop,&step);
    if((start-stop)*step>=0)
        {
            printf("输入有问题！请重新输入！");
        }
    else
        {
            f=start;
            while(i<=(-(start-stop)/step))
            {
                c=5.0/9.0*(f-32);
                printf("%f->%f\n",f,c);
                f=f+step;
                i++;
            }
        }
    return 0;
}