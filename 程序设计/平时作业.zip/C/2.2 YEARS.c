#include<stdio.h>
int main()
{
    int year,start,stop;
    printf("请输入起始年份和终止年份:");
    scanf("%d%d",&start,&stop);
    for(year=start;year<=stop;year++)
        {
            if((year%4==0 && year%100!=0)||(year%4==0 && year%100==0 && year%400==0))
            {
                printf("%d 是 闰年\n",year);
            }    
            else
            {
                printf("%d 不是 闰年\n",year);
            }
        }
return 0;
}